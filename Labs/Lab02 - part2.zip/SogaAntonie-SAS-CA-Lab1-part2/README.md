# Cryptography Exercises Solution

**Name:** Antonie Șoga

**Jupyter Notebook:** [Link to Colab Notebook](https://colab.research.google.com/drive/1vfuVIyVObzaosacgiSqb_Mha-kPZPx2V?usp=sharing)

---

## TODO 1.A – Compute the Frequency of the Letters in the Coset Shifted to the Left by the Shift Parameter  

### Approach:
1. Initialize an empty dictionary `freq` to store letter frequencies.  
2. Calculate the length of the coset.  
3. Create a shifted version of the coset by applying the inverse Caesar cipher with the given shift to each letter.  
4. Iterate through the alphabet. For each letter, count its occurrences in the shifted coset and divide by the total number of letters in the coset to get the frequency.  
5. Store the frequency in the `freq` dictionary.  
6. Return the `freq` dictionary.  

---

## TODO 1.B – Compute the Shift Which Leads to the Lowest Chi-Distribution  

### Approach:
1. Initialize `shift` to 0 and `min_chi_2` to infinity.  
2. Iterate through all possible shifts (0 to 25 for the English alphabet).  
3. For each shift, calculate the frequency distribution of the coset using `get_freq_dict`.  
4. Compute the chi-squared distribution of the calculated frequencies compared to the known English frequencies (`FREQS`).  
5. If the calculated chi-squared value is less than `min_chi_2`, update `min_chi_2` with this value and set `shift` to the current shift.  
6. After checking all possible shifts, return the `shift` that resulted in the minimum chi-squared distribution.  

---

## TODO 2.A – Implement `des2_enc`: First Encrypt with `k2`, Then Encrypt with `k1`  

### Approach:
1. Encrypt the message `m` with key `k2` using the `des_enc` function.  
2. Encrypt the result of the previous step with key `k1` using the `des_enc` function.  
3. Return the final ciphertext.  

---

## TODO 2.B – Implement `des2_dec`: First Decrypt with `k1`, Then Decrypt with `k2`  

### Approach:
1. Decrypt the ciphertext `c` with key `k1` using the `des_dec` function.  
2. Decrypt the result of the previous step with key `k2` using the `des_dec` function.  
3. Return the final plaintext.  

---

## TODO 2.C.3 – Decrypt `m2` Similar to `m1` (Note: `des_dec()` Returns Bytes)  

### Approach:
1. Use the `des2_dec` function with keys `k1` and `k2` to decrypt the ciphertext `c2`.  
2. Convert the resulting bytes plaintext to a string using `bytes_to_string`.  

---

## TODO 2.C.4 – Verify the Correctness of the Implementation  

### Approach:
1. Concatenate the byte representations of `c1` and `c2`.  
2. Decrypt the concatenated ciphertext using `des2_dec` with keys `k1` and `k2`.  
3. Convert the resulting bytes plaintext to a string using `bytes_to_string`.  
4. Concatenate the string representations of `m1` and `m2`.  
5. Assert that the decrypted concatenated ciphertext string is equal to the concatenated plaintext string.  

---

## TODO 2.D.2 – Convert `m1`, `m2`, `c1`, and `c2` to Bytes  

### Approach:
1. Use the provided `string_to_bytes` function to convert the string plaintexts `m1` and `m2` to bytes.  
2. Use the `bytes.fromhex` method to convert the hexadecimal strings `c1` and `c2` to bytes.  

---

## TODO 2.D.3 – Generate the Table Containing `(k2, des_enc(k2, m1))` for Every Possible `k2`  

### Approach:
1. Initialize an empty list `k2_table`.  
2. Iterate through all possible values for the first two bytes (0–255 for each byte).  
3. For each pair of bytes, create the full 8-byte key `k2` by concatenating the prefix and the known suffix.  
4. Encrypt `m1` with the current `k2` using `des_enc`.  
5. Append a tuple containing `k2` and the resulting ciphertext to `k2_table`.  

---

## TODO 2.D.5 – Perform Binary Search for All Possible `k1`  

### Approach:
1. Initialize an empty list `candidate_keys`.  
2. Iterate through all possible values for the first two bytes of `k1` (0–255 for each byte).  
3. For each pair of bytes, create the full 8-byte key `k1` by concatenating the prefix and the known suffix.  
4. Decrypt `c1` with the current `k1` using `des_dec`.  
5. Use the `get_index` function to search for the decrypted `c1` in the sorted list of `k2_ciphertexts`.  
6. If a match is found (index is not -1), retrieve the corresponding `k2` from the sorted `k2_table` using the index.  
7. Append the pair of candidate keys (`k1`, `k2`) to the `candidate_keys` list.  

---

## TODO 2.D.6 – Find and Print the Key Pairs Matching the Second Constraint  

### Approach:
1. Iterate through each candidate key pair (`k1`, `k2`) in the `candidate_keys` list.  
2. Encrypt the second plaintext `m2` using `des2_enc` with the current `k1` and `k2`.  
3. If the resulting ciphertext is equal to the second given ciphertext `c2`, print the key pair.  
