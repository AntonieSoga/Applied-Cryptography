# README: Secure Messaging Implementation (X3DH & Double Ratchet)

## 👤 Student Information

* **Name:** Antonie Șoga
* **Activity:** Secure Messaging Implementation Lab

---

## 💡 Implementation Strategy and Rationale

The goal of this lab was to implement the core cryptographic primitives for a secure messenger: the **Extended Triple Diffie-Hellman (X3DH)** protocol for initial key establishment and the **Double Ratchet Algorithm** for ongoing message security. The solutions below explain the "how and why" for each `TODO`.

### 1. X3DH Key Agreement (Initial Setup)

This phase establishes the shared, mutually authenticated **Master Secret (MS)**.

| File/Function | Implementation Details | Rationale |
| :--- | :--- | :--- |
| `Client.register` (1.1) | Implemented sending the public keys ($I_{pub}, S_{pub}, O_{pub}$ list) to the server using `self.s.send()` and `struct.pack('!i', ...)` for length. | Provides the recipient's pre-keys to the server, allowing any client to initiate a secure session using the X3DH protocol. |
| `Client.setup_session` (1.1, 1.2) | **Initiator** computes $\text{MS}$ as the concatenation of four Diffie-Hellman (DH) outputs: $\text{DH}(I_{ini}, S_{rec}) \| \text{DH}(E_{ini}, I_{rec}) \| \text{DH}(E_{ini}, S_{rec}) \| \text{DH}(E_{ini}, O_{rec})$. It then sends its Ephemeral Key ($E_{ini}$) to the server. | This combination ensures **mutual authentication** and **forward secrecy**. Sending $E_{ini}$ allows the recipient to complete its side of the DH exchanges and derive the same $\text{MS}$. |
| `Client.setup_session_rec` (1.2) | **Recipient** computes $\text{MS}$ using its private keys: $\text{DH}(S_{rec}, I_{ini}) \| \text{DH}(I_{rec}, E_{ini}) \| \text{DH}(S_{rec}, E_{ini}) \| \text{DH}(O_{rec}, E_{ini})$. The used $O_{rec}$ is then searched for in `self.O_queue` and removed. | **DH commutativity** guarantees the $\text{MS}$ is identical to the initiator's. Removing $O_{rec}$ from the queue maintains the protocol's security by ensuring the key is never reused (one-time pre-key). |

---

### 2. Double Ratchet Initialization and Symmetric-Key Ratchet

After X3DH, the $\text{MS}$ is converted into the initial keys for the Double Ratchet.

| File/Function | Implementation Details | Rationale |
| :--- | :--- | :--- |
| `record_new_client_session` (2.0) | Uses **HKDF** over the first ephemeral DH output ($\text{DH}(E_{own}, S_{rec})$) with the $\text{MS}$ as the salt, deriving the initial **Root Key ($\text{RK}$)** and **Sending Chain Key ($\text{CK}_s$)**. | **Key Derivation Function (KDF)** ensures cryptographic separation and uniform distribution of the initial key material, securely moving from the X3DH phase to the Double Ratchet phase. |
| `get_send_message_key` (2.1) | Implements the **Symmetric-Key Ratchet**: $\text{MK}_s = \text{HMAC}(\text{CK}_s, 0x01)$ and $\text{CK}_{s}' = \text{HMAC}(\text{CK}_s, 0x02)$. | This advances the chain key for every message sent. If an attacker compromises a future key ($\text{CK}_{s}'$), they cannot calculate the past $\text{MK}_s$ or $\text{CK}_s$, achieving **Perfect Forward Secrecy (PFS)** for messages. |
| `get_recv_message_key` (2.3) | Same HMAC structure as the sender's ratchet: $\text{MK}_r = \text{HMAC}(\text{CK}_r, 0x01)$ and $\text{CK}_{r}' = \text{HMAC}(\text{CK}_r, 0x02)$. | Advances the receiving chain for every message decrypted, ensuring receiving PFS. |

---

### 3. DH Ratchet (Vertical Ratchet)

This mechanism updates the Root Key whenever a new Ephemeral Public Key is exchanged, ensuring **Post-Compromise Security (PMC)**.

| File/Function | Implementation Details | Rationale |
| :--- | :--- | :--- |
| `Client.send_message` (2.2) | Sends the sender's current Ephemeral Public Key along with the ciphertext length and the ciphertext itself. | The public key acts as the **ratchet header**. It allows the recipient to detect a key change and perform the DH Ratchet, advancing the session. |
| `Client.recv_message` (3.0) | Checks if the received Ephemeral Public Key is different from the stored `session.eph_peer`. If it's new (or `None`), it triggers `session.update_keys()`. | This check is the trigger for the DH Ratchet. The recipient knows the sender has advanced their ephemeral key pair, requiring the recipient to advance its own keys to resume communication. |
| `ClientSession.update_keys` (2.4) | **Receiving Update:** Derives $\text{RK}'$ and $\text{CK}_r$ using $\text{HKDF}(\text{DH}(E_{own}, E_{peer}), \text{RK})$. **Sending Update:** Generates a new $E_{own}'$, then derives $\text{RK}''$ and $\text{CK}_s$ using $\text{HKDF}(\text{DH}(E_{own}', E_{peer}), \text{RK}')$. | The key update is a two-step process that **advances both the receiving and sending chains**. By mixing the new $\text{DH}$ output with the old $\text{RK}$, it establishes a secure "ratchet" that ensures any past compromise is irrelevant to future session keys (Post-Compromise Security). |