import sys
import random
import string
import operator

ALPHABET = 'ABCDEFGHIJKLMNOPQRSTUVWXYZ' # Global constant variables are usually named with capital letters

def caesar_enc(letter, k = 3):
  if letter < 'A' or letter > 'Z':
    # print('Invalid letter')
    return letter
  else:
    return ALPHABET[(ord(letter) - ord('A') + k) % len(ALPHABET)]

def caesar_dec(letter, k = 3):
    if letter < 'A' or letter > 'Z':
        # print('Invalid letter')
        return letter
    else:
        return ALPHABET[(ord(letter) - ord('A') - k) % len(ALPHABET)]

def caesar_enc_string(plaintext, k = 3):
    ciphertext = ''
    for letter in plaintext:
        ciphertext = ciphertext + caesar_enc(letter, k)
    return ciphertext

def caesar_dec_string(ciphertext, k = 3):
    plaintext = ''
    for letter in ciphertext:
        plaintext = plaintext + caesar_dec(letter, k)
    return plaintext

def main():
  m = 'BINEATIVENIT'
  c = caesar_enc_string(m)
  print(c)
  d = caesar_dec_string(c)
  print(d) 

  print(caesar_enc_string('HELLO'))
  print(caesar_enc_string('HELLO', 0))
  print(caesar_enc_string('HELLO', 1))

  m = 'ARBITRARY KEY EX@MPLE!'
  c = caesar_enc_string(m, 700)
  print(c)
  d = caesar_dec_string(c, 700)
  print(d)

  
  
if __name__ == "__main__":
  main()