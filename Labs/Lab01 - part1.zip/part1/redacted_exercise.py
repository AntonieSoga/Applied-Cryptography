from format_converter import *
def main():
    C1 = "000100010001000000001100000000110001011100000111000010100000100100011101000001010001100100000101"
    C2 = "02030F07100A061C060B1909"

    key = "abcdefghijkl"

    # Solve here

    # Step 1: Convert the key to the formats matching the ciphertexts
    key_bin = str_2_bin(key)  
    key_hex = str_2_hex(key)  

    # Step 2: Decrypt C1 (binary ciphertext)
    # XOR the binary ciphertext with the binary key
    plaintext1_bin = bitxor(C1, key_bin)
    plaintext1 = bin_2_str(plaintext1_bin)

    print(plaintext1)

    # Step 3: Decrypt C2 (hexadecimal ciphertext)
    # XOR the hexadecimal ciphertext with the hexadecimal key
    plaintext2_hex = hexxor(C2, key_hex)
    plaintext2 = hex_2_str(plaintext2_hex)

    print(plaintext2)  


if __name__ == "__main__":
  main()