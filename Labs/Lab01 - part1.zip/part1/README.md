# Cryptography Exercises Solution

**Name:** Antonie Șoga


---

## Exercise 1: Caesar Cipher Implementation

**Approach:**

- Implemented a basic Caesar cipher for uppercase English letters.
- Created functions for:
  - `caesar_enc(letter, k)` → Encrypt a single letter with key `k`.
  - `caesar_dec(letter, k)` → Decrypt a single letter with key `k`.
  - `caesar_enc_string(plaintext, k)` → Encrypt a full string.
  - `caesar_dec_string(ciphertext, k)` → Decrypt a full string.
- Used modular arithmetic to wrap around the alphabet (A-Z).
- Handled non-alphabet characters by returning them unchanged.
- Tested with multiple keys including default (`k=3`) and large keys (`k=700`).

## Exercise 2: XOR Cipher Decryption

**Initial info:**

- Ciphertext is encrypted using XOR: ciphertext = plaintext XOR key.

- Provided two ciphertexts:

    - C1 → Binary format

    - C2 → Hexadecimal format

- Key is a string "abcdefghijkl".

- Steps:

    - Convert the key to the appropriate format:

        - C1 → convert key to binary (str_2_bin)

        - C2 → convert key to hexadecimal (str_2_hex)

    - XOR the ciphertext with the key:

        - C1 → use bitxor

        - C2 → use hexxor

    - Convert the XOR result back to string:

        - Binary → bin_2_str

        - Hex → hex_2_str

- Output the decrypted plaintexts.