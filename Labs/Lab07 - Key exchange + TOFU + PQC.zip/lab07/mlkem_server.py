"""
UNSTPB, SAS, Applied Cryptography, Trust On First Use laboratory.

Server implementation of the TOFU protocol using ML-KEM key exchange.
"""

import socket
import base64
import argparse
import secrets # Added for ML-KEM
from mlkem.ml_kem import ML_KEM # Added for PQC
from mlkem.parameter_set import ML_KEM_768 # Added for PQC
from Crypto.PublicKey import RSA
from Crypto.Signature import pkcs1_15
from Crypto.Hash import SHA256
from Crypto.Protocol.KDF import HKDF
# pyasn1 and load_dh_parameters are no longer needed

# --- ML-KEM-768 constant sizes ---
# We hardcode these for simplicity in our protocol
MLKEM_PUBLIC_KEY_LEN = 1184
MLKEM_CIPHERTEXT_LEN = 1088
MLKEM_SHARED_SECRET_LEN = 32

def send_data(sock, data):
    """
    Send data to the socket.

    Args:
        - sock (socket): The socket to send data to.
        - data (bytes): The data to send.

    Returns:
        - None
    """

    sock.sendall(data)

def receive_data(sock, length):
    """
    Receive data from the socket.

    Args:
        - sock (socket): The socket to receive data from.
        - length (int): The number of bytes to receive.

    Returns:
        - data (bytes): The received data.
    """

    data = b""
    while len(data) < length:
        packet = sock.recv(length - len(data))
        if not packet:
            raise ConnectionError("Socket connection broken")
        data += packet
    return data

def sign_message(rsa_key, message):
    """
    Sign a message using the RSA private key.

    Args:
        - rsa_key (RSA key): The RSA private key.
        - message (bytes): The message to sign.

    Returns:
        - (bytes): The signature.
    """

    # This function remains unchanged
    h = SHA256.new(message)
    signature = pkcs1_15.new(rsa_key).sign(h)
    return signature

def main(server_ip, server_port, private_key_file):
    """
    Main function that implements the TOFU server.

    Args:
        - server_ip (str): The server's IP address (default: 127.0.0.1).
        - server_port (int): The server's port number (default: 1337).
        - private_key_file (str): The server's RSA private key file.
    
    Returns:
        - None
    """

    # Load RSA private key (unchanged)
    with open(private_key_file, "rb") as f:
        rsa_key = RSA.import_key(f.read())

    # TODO 3: Generate ML-KEM key pair instead of Diffie-Hellman
    print("[server] Generating ML-KEM key pair (this may take a moment)...")
    ml_kem = ML_KEM(parameters=ML_KEM_768)
    # ek_server is the public key (ek), dk_server is the private key (dk)
    ek_server, dk_server = ml_kem.key_gen()
    print("[server] ML-KEM key pair generated.")
    assert len(ek_server) == MLKEM_PUBLIC_KEY_LEN

    # Create a TCP socket (reusable, listening, bound to the server IP and port)
    server_socket = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
    server_socket.setsockopt(socket.SOL_SOCKET, socket.SO_REUSEADDR, 1)
    server_socket.bind((server_ip, server_port))
    server_socket.listen(5)

    print(f"[server] Listening on {server_ip}:{server_port}...")

    while True:
        client_socket, client_address = server_socket.accept()
        print(f"[server] Connection accepted from {client_address}")

        try:
            # TODO 1.2 Send RSA public key (unchanged)
            rsa_public_key_bytes = rsa_key.public_key().export_key(format='PEM')
            print("[server] Sending RSA public key...")
            send_data(client_socket, rsa_public_key_bytes)

            # TODO 3: Send ML-KEM public key (replaces DH public key)
            print("[server] Sending ML-KEM public key...")
            send_data(client_socket, ek_server)

            # TODO 3: Send signature over (RSA public key + ML-KEM public key)
            message_to_sign = rsa_public_key_bytes + ek_server
            signature = sign_message(rsa_key, message_to_sign)
            print("[server] Sending signature...")
            send_data(client_socket, signature)

            # TODO 3: Receive the client's ML-KEM ciphertext (replaces client DH key)
            client_ciphertext_bytes = receive_data(client_socket, MLKEM_CIPHERTEXT_LEN)
            print(f"[server] Received client ciphertext.")

            # TODO 3: Compute shared secret by decapsulating the ciphertext
            # This replaces compute_shared_key()
            try:
                shared_key_bytes = ml_kem.decaps(dk_server, client_ciphertext_bytes)
                print("[server] Successfully decapsulated shared secret.")
                assert len(shared_key_bytes) == MLKEM_SHARED_SECRET_LEN
            except ValueError as e:
                print(f"[server] Decapsulation failed! {e}. Aborting.")
                client_socket.close()
                continue

            # TODO 1.7 Derive a symmetric key from the shared secret using HKDF
            # This step is technically redundant as ML-KEM already produces a
            # secure 32-byte key, but we follow the lab spec.
            derived_key = HKDF(master=shared_key_bytes, key_len=32, salt=None, hashmod=SHA256)

            print(f"[server] Derived symmetric key: {derived_key.hex()}")

        except ConnectionError as e:
            print(f"[server] Connection error: {e}")
            client_socket.close()

        finally:
            client_socket.close()
            print("[server] Connection closed")

if __name__ == "__main__":

    parser = argparse.ArgumentParser(description="TOFU Server (PQC Edition)")
    parser.add_argument("-i", "--ip", type=str, default="127.0.0.1", help="Server IP")
    parser.add_argument("-p", "--port", type=int, default=1337, help="Server port")
    parser.add_argument("-k", "--key", type=str, default="private.pem", help="RSA private key file")

    args = parser.parse_args()
    main(args.ip, args.port, args.key)
