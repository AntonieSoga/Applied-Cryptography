"""
UNSTPB, SAS, Applied Cryptography, Trust On First Use laboratory.

Client implementation of the TOFU protocol using Diffie-Hellman key exchange.
"""

import os
import socket
import argparse
import base64
from pyasn1.codec.der.decoder import decode
from pyasn1.type.univ import Sequence
from Crypto.PublicKey import RSA
from Crypto.Signature import pkcs1_15
from Crypto.Hash import SHA256
from Crypto.Protocol.KDF import HKDF
from Crypto.Random import get_random_bytes

def load_dh_parameters():
    """
    Load Diffie-Hellman parameters from the dhparam.pem file.

    NOTE: these are usually standard - check RFC 7919 - we are
    using a custom one for simplicity, but these would normally be
    hardcoded in a real-world scenario.

    Returns:
        - P (int): The prime modulus.
        - G (int): The generator.
    """

    with open("dhparam.pem", "rb") as f:
        pem_data = f.read().split(b"\n")[1:-2] # Remove PEM header/footer

    # Get a single inline string and decode base64
    pem_data = b"".join(pem_data)
    der_data = base64.b64decode(pem_data)

    # Decode binarized DER data
    dh_params, _ = decode(der_data, asn1Spec=Sequence())

    P = int(dh_params[0])  # First integer in the sequence is P
    G = int(dh_params[1])  # Second integer in the sequence is G

    return P, G

def compute_shared_key(private_key, peer_public_key, P):
    """
    Compute the shared key using the private key and the peer's public key.

    Args:
        - private_key (int): This instance's private key.
        - peer_public_key (int): The peer's public key.
        - P (int): The prime modulus.

    Returns:
        - (int): The computed shared key.
    """

    # TODO 1.6
    return pow(peer_public_key, private_key, P)

def send_data(sock, data):
    """
    Send data to the socket.

    Args:
        - sock (socket): The socket to send data to.
        - data (bytes): The data to send.

    Returns:
        - None
    """

    sock.sendall(data)

def receive_data(sock, length):
    """
    Receive data from the socket.

    Args:
        - sock (socket): The socket to receive data from.
        - length (int): The number of bytes to receive.

    Returns:
        - data (bytes): The received data.
    """

    data = b""
    while len(data) < length:
        packet = sock.recv(length - len(data))
        if not packet:
            raise ConnectionError("Socket connection broken")
        data += packet
    return data

def receive_until_end_marker(sock, end_marker):
    """
    Receive data from the socket until the end_marker is found.

    Args:
        - sock (socket): The socket to receive data from.
        - end_marker (bytes): The end marker to look for.
    
    Returns:
        - data (bytes): The received data.
    """

    data = b""
    while True:
        chunk = sock.recv(3)
        if not chunk:
            raise ConnectionError("Socket connection closed before end marker was found")
        data += chunk
        if end_marker in data:
            break
    return data

def main(server_ip, server_port):
    """
    Main function that implements the TOFU client.

    Args:
        - server_ip (str): The server's IP address (default: 127.0.0.1).
        - server_port (int): The server's port number (default: 1337).

    Returns:
        - None
    """

    # Initiate a TCP connection to the server
    client_socket = socket.socket(socket.AF_INET, socket.SOCK_STREAM)

    try:
        client_socket.connect((server_ip, server_port))
        print(f"[client] Connected to {server_ip}:{server_port}")

        # TODO 1.1 Receive RSA public key from server
        rsa_public_key_bytes = receive_until_end_marker(client_socket, b"-----END PUBLIC KEY-----") # Receive RSA public key
        server_rsa_key = RSA.import_key(rsa_public_key_bytes) # Import key for future use
        print("[client] Received RSA public key")

        # TODO 2.1 Check if the the hostname is known; if not, add it
        # Make sure that you also create the known_hosts file if it doesn't exist
        # The known_hosts file format should be, per line: hostname public_key

        # TODO 2.2 If the hostname is known, check if the public key matches
        # If it doesn't, print a warning and close the connection

        known_hosts_file = "known_hosts"

        hosts = {}
        # Create the file if it doesn't exist
        if not os.path.exists(known_hosts_file):
            with open(known_hosts_file, "w") as f:
                pass # Create empty file
        with open(known_hosts_file, "r") as f:
            for line in f:
                if line.strip():
                    try:
                        host, key_b64 = line.strip().split()
                        hosts[host] = key_b64
                    except ValueError:
                        print(f"[client] Warning: Malformed line in {known_hosts_file}")
        
        # We store the base64 of the raw PEM bytes for comparison
        received_key_b64 = base64.b64encode(rsa_public_key_bytes).decode('utf-8')

        if server_ip not in hosts:
            # -> 2.1: First time connecting (Trust On First Use)
            print(f"[client] First time connecting to {server_ip}.")
            print("[client] Adding server's public key to known_hosts.")
            with open(known_hosts_file, "a") as f:
                f.write(f"{server_ip} {received_key_b64}\n")
        else:
            # -> 2.2: Host is known, verify the key
            print(f"[client] Verifying known host {server_ip}...")
            stored_key_b64 = hosts[server_ip]
            
            if stored_key_b64 != received_key_b64:
                # Key mismatch! Potential MITM attack.
                print("!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!")
                print("[client] WARNING: REMOTE HOST IDENTIFICATION HAS CHANGED!")
                print("[client] IT IS POSSIBLE THAT SOMEONE IS DOING SOMETHING NASTY!")
                print("[client] (Man-in-the-Middle attack?).")
                print("[client] Aborting connection.")
                client_socket.close()
                return
            else:
                # Key matches, all good.
                print("[client] Host key verified.")
        

        # TODO 1.2 Receive server's Diffie-Hellman public key
        server_public_key_bytes = receive_data(client_socket, 256)
        server_public_key = int.from_bytes(server_public_key_bytes, 'big')
        print(f"[client] Received server public key: {server_public_key}")

        # TODO 1.3 Receive the server's signature and verify it
        signature = receive_data(client_socket, 256)
        print("[client] Received server signature")
        message_to_verify = rsa_public_key_bytes + server_public_key_bytes
        hashed = SHA256.new(message_to_verify)

        try:
            pkcs1_15.new(server_rsa_key).verify(hashed, signature)
            print("[client] Server signature verified")
        except ValueError:
            print("[client] Server signature verification failed")
            client_socket.close()
            return

        # TODO 1.4 Generate client's Diffie-Hellman keys using the standard DH parameters
        P, G = load_dh_parameters()
        private_key = int.from_bytes(get_random_bytes(32), "big") % P
        public_key = pow(G, private_key, P) # G^b mod P

        # TODO 1.5 Send client's Diffie-Hellman public key
        public_key_bytes = public_key.to_bytes(256, 'big')
        print("[client] Sending DH public key...")
        send_data(client_socket, public_key_bytes)

        # TODO 1.6 Compute shared secret
        shared_key = compute_shared_key(private_key, server_public_key, P)

        # TODO 1.7 Derive a symmetric key from the shared secret using HKDF
        shared_key_bytes = shared_key.to_bytes(256, 'big')
        derived_key = HKDF(master=shared_key_bytes, key_len=32, salt=None, hashmod=SHA256)

        print(f"[client] Derived symmetric key: {derived_key.hex()}")

    except ConnectionError as e:
        print(f"[client] Connection error: {e}")
        client_socket.close()

    finally:
        client_socket.close()
        print("[client] Connection closed")

if __name__ == "__main__":

    parser = argparse.ArgumentParser(description="TOFU Client")
    parser.add_argument("-i", "--ip", type=str, default="127.0.0.1", help="Server IP")
    parser.add_argument("-p", "--port", type=int, default=1337, help="Server port")

    args = parser.parse_args()
    main(args.ip, args.port)
