# Lab 6b: TOFU-Based Authenticated Key Exchange (DH and PQC)

#### **Author: Antonie Șoga**

This project implements an authenticated key exchange (AKE) protocol between a client and server, secured with **Trust On First Use (TOFU)**.

The lab demonstrates two different key exchange mechanisms, both authenticated using the same TOFU/RSA signature scheme:
1.  **Part 1: Diffie-Hellman (DH)** - The classical, pre-quantum key exchange.

    ![alt text](images/image-6.png)
    ![alt text](images/image-5.png)


2.  **Part 2: ML-KEM (Kyber)** - A post-quantum (PQC) key encapsulation mechanism.

    The server's identity is established by a long-term **RSA key**. The client implements the TOFU mechanism, similar to SSH, by caching the server's RSA public key in a `known_hosts` file to prevent Man-in-the-Middle (MITM) attacks on subsequent connections.

    #### Core Features

    * **Server Authentication:** The server signs its ephemeral (per-session) key exchange public key with its long-term RSA private key.
    * **Trust On First Use (TOFU):** The client stores the server's long-term RSA public key on the first connection. All future connections must present the *same* RSA key, or the client will abort with a security warning.
    * **Post-Quantum Ready:** The protocol is "hybrid." It uses classical RSA for signatures but swaps in the PQC **ML-KEM** algorithm for the key exchange itself, providing security against attacks from quantum computers.
    * **Secure Key Derivation:** Uses **HKDF** (HMAC-based Key Derivation Function) to convert the shared secret from the key exchange into a final, 32-byte symmetric key suitable for encryption.

        ![alt text](images/image.png)
        ![alt text](images/image-1.png)


