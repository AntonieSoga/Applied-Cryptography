"""
UNSTPB, SAS, Applied Cryptography, Trust On First Use laboratory.

Client implementation of the TOFU protocol using ML-KEM key exchange.
"""

import os
import socket
import argparse
import base64
import secrets  # Added for ML-KEM
from mlkem.ml_kem import ML_KEM  # Added for PQC
from mlkem.parameter_set import ML_KEM_768  # Added for PQC
from Crypto.PublicKey import RSA
from Crypto.Signature import pkcs1_15
from Crypto.Hash import SHA256
from Crypto.Protocol.KDF import HKDF

# --- ML-KEM-768 constant sizes ---
MLKEM_PUBLIC_KEY_LEN = 1184
MLKEM_CIPHERTEXT_LEN = 1088
MLKEM_SHARED_SECRET_LEN = 32
RSA_SIGNATURE_LEN = 256  # Assuming 2048-bit RSA key


def send_data(sock, data):
    """Send data through the socket."""
    sock.sendall(data)


def receive_data(sock, length):
    """Receive a fixed number of bytes from the socket."""
    data = b""
    while len(data) < length:
        packet = sock.recv(length - len(data))
        if not packet:
            raise ConnectionError("Socket connection broken")
        data += packet
    return data


def receive_until_end_marker(sock, end_marker):
    """Receive data until the end marker (e.g., PEM footer) is found."""
    data = b""
    while True:
        chunk = sock.recv(1024)
        if not chunk:
            raise ConnectionError("Socket connection closed before end marker was found")
        data += chunk
        if end_marker in data:
            break
    return data


def main(server_ip, server_port):
    """Main function implementing the TOFU client using ML-KEM."""
    client_socket = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
    known_hosts_file = "known_hosts"

    try:
        client_socket.connect((server_ip, server_port))
        print(f"[client] Connected to {server_ip}:{server_port}")

        # --- Step 1: Receive RSA public key ---
        rsa_public_key_raw = receive_until_end_marker(client_socket, b"-----END PUBLIC KEY-----")
        end_marker = b"-----END PUBLIC KEY-----"
        end_index = rsa_public_key_raw.find(end_marker) + len(end_marker)
        rsa_public_key_bytes = rsa_public_key_raw[:end_index]
        leftover = rsa_public_key_raw[end_index:]  # Save any extra bytes

        print(f"[client] Received RSA public key ({len(rsa_public_key_bytes)} bytes)")
        server_rsa_key = RSA.import_key(rsa_public_key_bytes)

        # --- Step 2: Trust On First Use (TOFU) logic ---
        hosts = {}
        if not os.path.exists(known_hosts_file):
            open(known_hosts_file, "w").close()

        with open(known_hosts_file, "r") as f:
            for line in f:
                if line.strip():
                    try:
                        host, key_b64 = line.strip().split()
                        hosts[host] = key_b64
                    except ValueError:
                        print(f"[client] Warning: malformed line in {known_hosts_file}")

        received_key_b64 = base64.b64encode(rsa_public_key_bytes).decode("utf-8")

        if server_ip not in hosts:
            print(f"[client] First time connecting to {server_ip}.")
            print("[client] Adding server's public key to known_hosts.")
            with open(known_hosts_file, "a") as f:
                f.write(f"{server_ip} {received_key_b64}\n")
        else:
            print(f"[client] Verifying known host {server_ip}...")
            stored_key_b64 = hosts[server_ip]
            if stored_key_b64 != received_key_b64:
                print("!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!")
                print("[client] WARNING: REMOTE HOST IDENTIFICATION HAS CHANGED!")
                print("[client] Aborting connection.")
                client_socket.close()
                return
            else:
                print("[client] Host key verified.")

        # --- Step 3: Receive ML-KEM public key ---
        print("[client] Waiting for server's ML-KEM public key...")
        if leftover:
            print(f"[client] Using {len(leftover)} leftover bytes from RSA read.")
            if len(leftover) >= MLKEM_PUBLIC_KEY_LEN:
                server_public_key_bytes = leftover[:MLKEM_PUBLIC_KEY_LEN]
                leftover = leftover[MLKEM_PUBLIC_KEY_LEN:]
            else:
                needed = MLKEM_PUBLIC_KEY_LEN - len(leftover)
                server_public_key_bytes = leftover + receive_data(client_socket, needed)
                leftover = b""
        else:
            server_public_key_bytes = receive_data(client_socket, MLKEM_PUBLIC_KEY_LEN)

        print(f"[client] Received server ML-KEM public key ({len(server_public_key_bytes)} bytes)")

        # --- Step 4: Receive and verify signature ---
        if leftover and len(leftover) >= RSA_SIGNATURE_LEN:
            signature = leftover[:RSA_SIGNATURE_LEN]
        elif leftover:
            needed = RSA_SIGNATURE_LEN - len(leftover)
            signature = leftover + receive_data(client_socket, needed)
        else:
            signature = receive_data(client_socket, RSA_SIGNATURE_LEN)

        print(f"[client] Received server signature ({len(signature)} bytes)")

        message_to_verify = rsa_public_key_bytes + server_public_key_bytes
        hashed = SHA256.new(message_to_verify)

        try:
            pkcs1_15.new(server_rsa_key).verify(hashed, signature)
            print("[client] Server signature verified ✅")
        except ValueError:
            print("[client] Server signature verification failed ❌")
            client_socket.close()
            return

        # --- Step 5: Encapsulate shared secret ---
        print("[client] Encapsulating shared secret using ML-KEM...")
        ml_kem = ML_KEM(parameters=ML_KEM_768)
        shared_key_bytes, ciphertext_bytes = ml_kem.encaps(server_public_key_bytes)
        assert len(shared_key_bytes) == MLKEM_SHARED_SECRET_LEN
        assert len(ciphertext_bytes) == MLKEM_CIPHERTEXT_LEN

        # --- Step 6: Send ML-KEM ciphertext ---
        print(f"[client] Sending ML-KEM ciphertext ({len(ciphertext_bytes)} bytes)...")
        send_data(client_socket, ciphertext_bytes)

        # --- Step 7: Derive symmetric key ---
        derived_key = HKDF(master=shared_key_bytes, key_len=32, salt=None, hashmod=SHA256)
        print(f"[client] Derived symmetric key: {derived_key.hex()}")

    except ConnectionError as e:
        print(f"[client] Connection error: {e}")

    finally:
        client_socket.close()
        print("[client] Connection closed")


if __name__ == "__main__":
    parser = argparse.ArgumentParser(description="TOFU Client (PQC Edition)")
    parser.add_argument("-i", "--ip", type=str, default="127.0.0.1", help="Server IP")
    parser.add_argument("-p", "--port", type=int, default=1337, help="Server port")
    args = parser.parse_args()
    main(args.ip, args.port)
