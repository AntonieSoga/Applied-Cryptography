"""
UNSTPB, SAS, Applied Cryptography, Trust On First Use laboratory.

Server implementation of the TOFU protocol using Diffie-Hellman key exchange.
"""

import socket
import base64
import argparse
from pyasn1.codec.der.decoder import decode
from pyasn1.type.univ import Sequence
from Crypto.PublicKey import RSA
from Crypto.Signature import pkcs1_15
from Crypto.Hash import SHA256
from Crypto.Random import get_random_bytes
from Crypto.Protocol.KDF import HKDF

def load_dh_parameters():
    """
    Load Diffie-Hellman parameters from the dhparam.pem file.

    NOTE: these are usually standard - check RFC 7919 - we are
    using a custom one for simplicity, but these would normally be
    hardcoded in a real-world scenario.

    Returns:
        - P (int): The prime modulus.
        - G (int): The generator.
    """

    with open("dhparam.pem", "rb") as f:
        pem_data = f.read().split(b"\n")[1:-2] # Remove PEM header/footer

    pem_data = b"".join(pem_data)
    der_data = base64.b64decode(pem_data)

    # Decode binarized DER data
    dh_params, _ = decode(der_data, asn1Spec=Sequence())

    P = int(dh_params[0])  # First integer in the sequence is P
    G = int(dh_params[1])  # Second integer in the sequence is G

    return P, G

def compute_shared_key(private_key, peer_public_key, P):
    """
    Compute the shared key using the private key and the peer's public key.

    Args:
        - private_key (int): This instance's private key.
        - peer_public_key (int): The peer's public key.
        - P (int): The prime modulus.

    Returns:
        - (int): The computed shared key.
    """

    # TODO 1.6
    return pow(peer_public_key, private_key, P)

def send_data(sock, data):
    """
    Send data to the socket.

    Args:
        - sock (socket): The socket to send data to.
        - data (bytes): The data to send.

    Returns:
        - None
    """

    sock.sendall(data)

def receive_data(sock, length):
    """
    Receive data from the socket.

    Args:
        - sock (socket): The socket to receive data from.
        - length (int): The number of bytes to receive.

    Returns:
        - data (bytes): The received data.
    """

    data = b""
    while len(data) < length:
        packet = sock.recv(length - len(data))
        if not packet:
            raise ConnectionError("Socket connection broken")
        data += packet
    return data

def sign_message(rsa_key, message):
    """
    Sign a message using the RSA private key.

    Args:
        - rsa_key (RSA key): The RSA private key.
        - message (bytes): The message to sign.

    Returns:
        - (bytes): The signature.
    """

    # TODO 1.4
    h = SHA256.new(message)
    signature = pkcs1_15.new(rsa_key).sign(h)

    return signature

def main(server_ip, server_port, private_key_file):
    """
    Main function that implements the TOFU server.

    Args:
        - server_ip (str): The server's IP address (default: 127.0.0.1).
        - server_port (int): The server's port number (default: 1337).
        - private_key_file (str): The server's RSA private key file.
    
    Returns:
        - None
    """

    # Load RSA private key
    with open(private_key_file, "rb") as f:
        rsa_key = RSA.import_key(f.read())

    # TODO 1.1 Generate Diffie-Hellman parameters and keys

    P, G = load_dh_parameters()
    private_key = int.from_bytes(get_random_bytes(32), "big") % P
    public_key = pow(G, private_key, P) # G^a mod P

    # Create a TCP socket (reusable, listening, bound to the server IP and port)
    server_socket = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
    server_socket.setsockopt(socket.SOL_SOCKET, socket.SO_REUSEADDR, 1)
    server_socket.bind((server_ip, server_port))
    server_socket.listen(5)

    print(f"[server] Listening on {server_ip}:{server_port}...")

    while True:
        client_socket, client_address = server_socket.accept()
        print(f"[server] Connection accepted from {client_address}")

        try:
            # TODO 1.2 Send RSA public key
            rsa_public_key_bytes = rsa_key.public_key().export_key(format='PEM')
            print("[server] Sending RSA public key...")
            send_data(client_socket, rsa_public_key_bytes)

            # TODO 1.3 Send Diffie-Hellman public key
            public_key_bytes = public_key.to_bytes(256, 'big')
            print("[server] Sending DH public key...")
            send_data(client_socket, public_key_bytes)

            # TODO 1.4 Send signature of the hashed parameters (RSA public key and DH public key)
            message_to_sign = rsa_public_key_bytes + public_key_bytes
            signature = sign_message(rsa_key, message_to_sign)
            print("[server] Sending signature...")
            send_data(client_socket, signature)

            # TODO 1.5 Receive the client's Diffie-Hellman public key
            client_public_key_bytes = receive_data(client_socket, 256)
            client_public_key = int.from_bytes(client_public_key_bytes, 'big')
            print(f"[server] Received client public key: {client_public_key}")

            # TODO 1.6 Compute shared secret
            shared_key = compute_shared_key(private_key, client_public_key, P)
            shared_key_bytes = shared_key.to_bytes(256, 'big')

            # TODO 1.7 Derive a symmetric key from the shared secret using HKDF
            derived_key = HKDF(master=shared_key_bytes, key_len=32, salt=None, hashmod=SHA256)

            print(f"[server] Derived symmetric key: {derived_key.hex()}")

        except ConnectionError as e:
            print(f"[server] Connection error: {e}")
            client_socket.close()

        finally:
            client_socket.close()
            print("[server] Connection closed")

if __name__ == "__main__":

    parser = argparse.ArgumentParser(description="TOFU Server")
    parser.add_argument("-i", "--ip", type=str, default="127.0.0.1", help="Server IP")
    parser.add_argument("-p", "--port", type=int, default=1337, help="Server port")
    parser.add_argument("-k", "--key", type=str, default="private.pem", help="RSA private key file")

    args = parser.parse_args()
    main(args.ip, args.port, args.key)
