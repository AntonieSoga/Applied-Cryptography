


# CBC Padding Oracle Attack — Final Solution

**Author:** Antonie Șoga

**Context:** Lab exercise — recover plaintext from a CBC-encrypted ciphertext using only a padding oracle (`check_cbcpad(ciphertext, iv)`) and the known IV. The key is *not* available.

---
**Jupyter Notebook:** [Link to Colab Notebook](https://colab.research.google.com/drive/17iGFBTgG6DAHSkUAr_XHVDMucVOm3h9L?usp=sharing)

---
### SOLUTION :
` b'Fericiti cei curati cu inima, ca aceia vor vedea pe Dumnezeu\x04\x04\x04\x04' `

## Goal

Recover the original plaintext corresponding to the provided ciphertext using a CBC padding-oracle attack. The implementation is written inline (no helper functions) and is intended as my final submitted solution for the lab.

## Inputs

* `IV` — known initialization vector (16 bytes).
* `c` — ciphertext provided as a hex string; converted to `ct = binascii.unhexlify(c)` in the script.
* `check_cbcpad(ciphertext, iv)` — the lab-provided oracle that returns a truthy value when the decrypted plaintext has valid PKCS#7 padding and falsy otherwise.

## High-level approach

1. Treat the ciphertext as a sequence of 16-byte blocks (AES block size = 16).
2. Work block-by-block from the **last** ciphertext block backwards to the **first**.
3. For each target block `C_i`, use the previous block `C_{i-1}` (or `IV` if `i == 0`) as the place to inject guesses. By modifying bytes in the previous block and querying the oracle, we can learn the intermediate decrypted value `D_k(C_i)` — the result of decrypting `C_i` with the unknown key (but before XOR with `C_{i-1}`).
4. Once `D_k(C_i)` (the intermediate bytes) is recovered for a block, the plaintext block is obtained by XORing those intermediate bytes with `C_{i-1}` (or `IV` for the first block).
5. Prepend recovered plaintext blocks as we iterate backwards to reassemble the full message.

This follows the classic CBC padding-oracle attack: manipulate the previous ciphertext block to force chosen padding values after decryption and observe the oracle's boolean responses.

## Detailed algorithm / implementation notes

* **Block and length validation**: The script checks that the IV is exactly 16 bytes and that the ciphertext length is a multiple of 16.

* **Iterate from last block to first**: The loop `for block_index in range(num_blocks - 1, -1, -1):` ensures we recover blocks in reverse order. Recovered plaintext for each block is then prepended to the running `decrypted_message` buffer.

* **Intermediate byte recovery**:

  * For each target byte position in a block (iterate from index 15 down to 0), set the desired padding value `target_padding = 16 - byte_index_to_attack`.
  * Construct a `modified_previous_block` starting from the original previous block (or IV). For every byte position already recovered to the right of the target byte, set the byte so that after decryption it produces the desired padding value. This is done by `modified_previous_block[j] = intermediate_bytes[j] ^ target_padding`.
  * Iterate `guess` from 0..255 and set `modified_previous_block[byte_index_to_attack] = guess`. Concatenate this modified previous block with the current ciphertext block and query the oracle.
  * If the oracle reports valid padding, compute the intermediate byte as `recovered_intermediate_byte = guess ^ target_padding`, then compute the plaintext byte as `recovered_intermediate_byte ^ previous_block[byte_index_to_attack]`.


## Why this works

* CBC decryption of a ciphertext block `C_i` produces: `P_i = D_k(C_i) XOR C_{i-1}` (with `C_{i-1} = IV` for the first block). The oracle only tells us whether `P_i` has valid PKCS#7 padding, not the decryption itself.
* By controlling bytes of `C_{i-1}` we can force chosen values for the last `n` bytes of `P_i`. When the oracle returns "valid", we know those last `n` bytes match a valid PKCS#7 padding pattern (`0x01`, or `0x02 0x02`, ..., up to `0x10 * 16`), and that gives us equations that reveal `D_k(C_i)` byte-by-byte.


## Soluition output (what to expect)

* Per-byte recovery lines like:

  
  Block 3 byte 15: intermediate=0x12, plaintext=0x41
  
* Final lines like:

  
  Decrypted message:
    b'Fericiti cei curati cu inima, ca aceia vor vedea pe Dumnezeu\x04\x04\x04\x04'
  

That's the write-up of my approach and implementation for the CBC padding-oracle lab.
