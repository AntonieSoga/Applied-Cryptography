# Lab 04 – Public Key Encryption (Diffie–Hellman Key Exchange)

### **Author:** Antonie Șoga

### **Overview:** 
This lab implements the missing parts of a Diffie–Hellman (DH) key exchange between a client and a server using OpenSSL 1.1.1.
Both sides generate DH key pairs, exchange public keys, and compute a shared secret.

## Implemented TODOs

- ### TODO1 - Generate DH Keys

    In both dhe.c and dhe_server.c, the Diffie–Hellman key pair is generated using:

    ```c
    CHECK(DH_generate_key(tdh) == 1, "DH_generate_key");
    ```
    This function creates the private and public DH keys based on the parameters (p, g) read from dhparam.pem.


- ### TODO 2 – Retrieve Public and Private Keys

    ```c
    DH_get0_key(tdh, (const BIGNUM **)&pub_key, (const BIGNUM **)&priv_key);
    ```

    This allows us to export the public key to binary form using BN_bn2bin() for transmission.


- ### TODO 3 – Import Peer’s Public Key

    The received public key bytes from the other party are converted back into a BIGNUM:

    ```c
    pub_key_theirs = BN_bin2bn(buf_pubkey_theirs, PUB_KEY_LEN, NULL);
    ```
    This prepares it for use in the shared key computation.

- ### TODO 4 – Compute Shared Secret

    Finally, both client and server compute the shared secret using:
    ```c
    n = DH_compute_key(buf_secret_key, pub_key_theirs, tdh);
    ```
    The resulting secret (buf_secret_key) is identical on both sides, confirming a successful key exchange.


## Result
- Both client and server print:

- Their own public key (in hex)

- The received public key

- The shared secret, which match on both ends.

![RESULT](image.png)