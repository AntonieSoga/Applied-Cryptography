# Lab 05 - PKI and TLS

#### **Author:** *Antonie Soga*

---

## Task 1: Investigate Certificates for ocw.cs.pub.ro

### a. Server Certificate Information

**Command used:**

```bash
true | openssl s_client -connect ocw.cs.pub.ro:443 2>/dev/null | openssl x509 > ocwcspubro.crt
```

**Display full certificate:**

```bash
openssl x509 -in ocwcspubro.crt -noout -text
```

#### Subject

```
C=RO, L=București, O=POLITEHNICA București, CN=ocw.cs.pub.ro
```

#### Issuer

```
C=GR, O=Hellenic Academic and Research Institutions CA, CN=GEANT TLS RSA 1
```

#### Validity

```
Not Before: Jun 29 07:12:27 2025 GMT
Not After : Jun 29 07:12:27 2026 GMT
```

#### Public Key

```
RSA Public-Key: (2048 bit)
Modulus (example):
  D262EB81DFA6360D8D383D21EC8EF554B13C0F099B8932526D6528BA166DFE6C...
Exponent: 65537 (0x10001)
```

#### SHA256 Fingerprint

```
E5:CC:2A:CC:15:08:2D:FE:52:B7:3B:83:D7:24:46:31:6E:9C:DD:8A:2B:B9:21:7F:E6:3C:AD:CA:EC:B5:8C:33
```

---

### b. Issuer (Intermediate) Certificate – TERENA SSL CA 3

**Command used:**

```bash
openssl x509 -in TERENASSLCA3.crt -noout -text
```

#### Subject

```
C=NL, ST=Noord-Holland, L=Amsterdam, O=TERENA, CN=TERENA SSL CA 3
```

#### Issuer

```
C=US, O=DigiCert Inc, OU=www.digicert.com, CN=DigiCert Assured ID Root CA
```

#### SHA256 Fingerprint

```
BE:B8:EF:E9:B1:A7:3C:84:1B:37:5A:90:E5:FF:F8:04:88:48:E3:A2:AF:66:F6:C4:DD:7B:93:8D:6F:E8:C5:D8
```

---

### c. Root Certificate – TERENA SSL Root CA

**Subject**

```
C=US, postalCode=47907, ST=Indiana, L=West Lafayette,
street=155 S. Grant St., O=Purdue University,
OU=IT Systems and Operations, CN=www.distance.purdue.edu
```

**Issuer**

```
C=US, O=Internet2, OU=InCommon, CN=InCommon Server CA
```

**SHA256 Fingerprint**

```
88:3E:88:E5:D3:5D:96:3B:A2:45:64:7A:7C:96:58:81:48:5A:44:86:CC:76:04:DD:51:6B:1B:E1:79:47:91:C6
```

---

### d. Verification

#### Command used:

```bash
openssl verify -CAfile TERENASSLCA3.crt ocwcspubro.crt
```

#### Result:

```
error 20 at 0 depth lookup: unable to get local issuer certificate
error ocwcspubro.crt: verification failed
```

This occurs because the certificate chain provided by `ocwcspubro.crt` does **not** match the TERENA chain; the current server uses the **HARICA GEANT TLS RSA** hierarchy instead.

---

### e. Updated Chain (from Server)

**Server chain (via `openssl s_client -showcerts -connect ocw.cs.pub.ro:443`):**

1. `ocw.cs.pub.ro` – issued by **GEANT TLS RSA 1**
2. `GEANT TLS RSA 1` – issued by **HARICA TLS RSA Root CA 2021**
3. `HARICA TLS RSA Root CA 2021` – issued by **Hellenic Academic and Research Institutions RootCA 2015**

Verification result:

```bash
openssl verify -CAfile root.pem -untrusted interm.pem server-cert-1.pem
```

 **server-cert-1.pem: OK**

---

### 6. Summary

| Field                    | Value                                                                                           |
| ------------------------ | ----------------------------------------------------------------------------------------------- |
| **Common Name (CN)**     | ocw.cs.pub.ro                                                                                   |
| **Organization (O)**     | POLITEHNICA București                                                                           |
| **Issuer CN**            | GEANT TLS RSA 1                                                                                 |
| **Validity**             | 29 Jun 2025 → 29 Jun 2026                                                                       |
| **Public Key Type**      | RSA 2048 bits                                                                                   |
| **Fingerprint (SHA256)** | E5:CC:2A:CC:15:08:2D:FE:52:B7:3B:83:D7:24:46:31:6E:9C:DD:8A:2B:B9:21:7F:E6:3C:AD:CA:EC:B5:8C:33 |
| **Verification Result**  | OK (with HARICA Root)                                                                           |

---

**Conclusion:**
The website `ocw.cs.pub.ro` currently uses a certificate issued by the **Hellenic Academic and Research Institutions CA (HARICA)** under the **GEANT TLS RSA 1** hierarchy.
Older TERENA certificates (`TERENASSLCA3.crt`) no longer match the current trust chain.

---
---

## Task 2: Investigate the TLS cryptographic parameters

### a. Google.com

**TLS Version and Cipher:**
- Protocol: TLSv1.3
- Cipher: TLS_AES_256_GCM_SHA384
- Server Public Key: 256 bit
- Verify return code: 0 (ok)

**Certificates:**
#### Server Certificate (google.com-cert-1.pem)
- Subject: CN=google.com, O=Google LLC, L=Mountain View, C=US
- Issuer: CN=GTS CA 1O1, O=Google Trust Services, C=US
- Validity: Not Before / Not After
- Public Key: 256-bit EC
- SHA256 Fingerprint: XX:XX:...

#### Intermediate Certificate (google.com-cert-2.pem)
- Subject: CN=GTS CA 1O1, O=Google Trust Services, C=US
- Issuer: CN=GTS Root R1, O=Google Trust Services, C=US
- Public Key: 2048-bit RSA

#### Root Certificate (google.com-cert-3.pem)
- Subject = Issuer: CN=GTS Root R1, O=Google Trust Services, C=US
- Public Key: 4096-bit RSA
- Self-signed

---

### b. Amazon.com

**TLS Version and Cipher:**
- Protocol: TLSv1.3
- Cipher: TLS_AES_128_GCM_SHA256
- Server Public Key: 2048 bit
- Verify return code: 0 (ok)

**Certificates:**
#### Server Certificate (amazon.com-cert-1.pem)
- Subject: CN=*.amazon.com, O=Amazon.com, Inc., L=Seattle, C=US
- Issuer: CN=Amazon RSA 2048 M01, O=Amazon, C=US
- Public Key: 2048-bit RSA

#### Intermediate Certificate (amazon.com-cert-2.pem)
- Subject: CN=Amazon RSA 2048 M01, O=Amazon, C=US
- Issuer: CN=Amazon Root CA 1, O=Amazon, C=US
- Public Key: 2048-bit RSA

#### Root Certificate (amazon.com-cert-3.pem)
- Subject = Issuer: CN=Amazon Root CA 1, O=Amazon, C=US
- Public Key: 2048-bit RSA
- Self-signed

---

### Notes

- **Root vs Intermediate Certificates**:  
  - Root: Self-signed (Subject = Issuer), typically highly trusted.  
  - Intermediate: Signed by another CA (Issuer ≠ Subject), used to form a trust chain.  
- **Server Certificate**: Issued to the domain (CN matches website), signed by intermediate CA.  
- TLS versions differ slightly (TLS 1.3) and ciphers vary (Google uses AES-256, Amazon uses AES-128).


## Task 3: Investigate the TLS handshake protocol

### Traffic Capture 1

**ClientHello Analysis**

* **Number of cipher suites offered:** 85
* **TLS version proposed:** TLS 1.2
* **Server Name Indication (SNI):** None (empty)
* **Cipher suites highlights:** Includes `TLS_ECDHE_RSA_WITH_AES_256_GCM_SHA384`, `TLS_ECDHE_ECDSA_WITH_AES_256_GCM_SHA384`, `TLS_RSA_WITH_AES_256_GCM_SHA384`, etc.
* **Extensions:** `supported_groups`, `ec_point_formats`, `session_ticket`, `signature_algorithms`, `extended_master_secret`, `renegotiation_info`.

**Negotiated Algorithms**

* **Selected cipher suite:** `TLS_ECDHE_RSA_WITH_AES_256_GCM_SHA384`
* **Key exchange:** ECDHE (Ephemeral Elliptic Curve Diffie-Hellman)
* **Encryption:** AES-256-GCM
* **Message authentication:** SHA384

**Information in Cleartext**

* ClientHello fields (TLS version, supported cipher suites, extensions)
* Random nonce
* SNI (server_name) if present

**Security Observations**

* Downgrade attacks could be attempted by forcing the client and server to select weaker cipher suites (e.g., older TLS 1.0 or weak CBC modes).
* Sensitive information (credentials, session data) is **not sent in cleartext** in TLS handshake.

---

### Traffic Capture 2

**ClientHello Analysis**

* **Number of cipher suites offered:** 15
* **TLS version proposed:** TLS 1.2
* **Server Name Indication (SNI):** `ocw.cs.pub.ro`
* **Cipher suites highlights:** Includes `TLS_ECDHE_ECDSA_WITH_AES_128_GCM_SHA256`, `TLS_ECDHE_RSA_WITH_AES_128_GCM_SHA256`, `TLS_ECDHE_ECDSA_WITH_CHACHA20_POLY1305_SHA256`, `TLS_ECDHE_RSA_WITH_CHACHA20_POLY1305_SHA256`, etc.
* **Extensions:** `server_name`, `extended_master_secret`, `renegotiation_info`, `supported_groups`, `ec_point_formats`, `session_ticket`, `application_layer_protocol_negotiation (ALPN)`, `status_request`, `signature_algorithms`.

**Negotiated Algorithms**

* **Selected cipher suite:** `TLS_ECDHE_RSA_WITH_AES_128_GCM_SHA256`
* **Key exchange:** ECDHE
* **Encryption:** AES-128-GCM
* **Message authentication:** SHA256

**Information in Cleartext**

* ClientHello fields (TLS version, supported cipher suites, extensions)
* SNI (`ocw.cs.pub.ro`)
* Random nonce

**Security Observations**

* Cleartext SNI could reveal which host the client wants to connect to.
* Downgrade attacks could be attempted by manipulating handshake to force a weaker cipher suite or older TLS version, but modern clients usually prevent this via `renegotiation_info` and `extended_master_secret`.

---

### Analysis Summary

| Capture | # Cipher Suites | TLS Version | SNI Present           | Selected Cipher                       | Key Exchange | Encryption  | MAC    |
| ------- | --------------- | ----------- | --------------------- | ------------------------------------- | ------------ | ----------- | ------ |
| 1       | 85              | TLS 1.2     | No                    | TLS_ECDHE_RSA_WITH_AES_256_GCM_SHA384 | ECDHE        | AES-256-GCM | SHA384 |
| 2       | 15              | TLS 1.2     | Yes (`ocw.cs.pub.ro`) | TLS_ECDHE_RSA_WITH_AES_128_GCM_SHA256 | ECDHE        | AES-128-GCM | SHA256 |

**Purpose of `server_name` extension:**

* Enables the server to present the correct certificate when multiple domains are hosted on the same IP.

**Cleartext fields:**

* ClientHello information (cipher suites, TLS version, extensions, random bytes)
* SNI (server_name)

**Downgrade attack feasibility:**

* By manipulating handshake messages to force weak ciphers or old TLS versions.
* Mitigated by modern TLS features like `renegotiation_info` and `extended_master_secret`.
